package com.example.yourjob;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2z extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity2z);
        TextView r1 = findViewById(R.id.textView);
        TextView r2 = findViewById(R.id.textView2);
        TextView r3 = findViewById(R.id.textView3)  ;
        TextView r4 = findViewById(R.id.textView4);
        TextView r5 = findViewById(R.id.textView5);







      Bundle mohammed = getIntent().getExtras();

        r1.setText(mohammed.getString("oo"));
           r2.setText(mohammed.getString("oo"));
           r3.setText(mohammed.getString("uu"));
           r4.setText(     mohammed.getString("rr"));
          r5.setText(     mohammed.getString("gg"));




    }
}