package com.example.yourjob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      final EditText x1 = findViewById(R.id.editTextTextPersonName);
      final EditText x2 = findViewById(R.id.editTextTextPersonName2);
     final EditText x3 = findViewById(R.id.editTextTextPersonName3);
      final EditText x4 = findViewById(R.id.editTextTextPersonName4);
        Button v1 = findViewById(R.id.button);

        v1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              x1.getText().toString();
              x2.getText().toString();
              x3.getText().toString();
              x4.getText().toString();

             String h2 = x1.getText().toString();
             String h3 = x2.getText().toString();
             String h4 =  x3.getText().toString();
             String h5 =  x4.getText().toString();

                Intent v2 = new Intent(MainActivity.this,MainActivity2z.class);
               v2.putExtra("oo",h2);
               v2.putExtra("uu",h3);
               v2.putExtra("rr",h4);
                v2.putExtra("gg",h5);

               startActivity(v2);




            }
        });


    }
}